<?php

require_once(__DIR__ . "/code/FieldTypes.class.php");
require_once(__DIR__ . "/code/FieldTypeSettings.class.php");
require_once(__DIR__ . "/code/Module.class.php");
require_once(__DIR__ . "/code/Validation.class.php");
